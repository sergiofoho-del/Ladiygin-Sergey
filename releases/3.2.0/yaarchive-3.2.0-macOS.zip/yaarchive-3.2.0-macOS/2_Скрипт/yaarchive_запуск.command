#!/bin/bash
# yaarchive — двойной щелчок (macOS): обработать все загрузки в этой папке (без вопросов) и открыть Excel
cd "$(dirname "$0")"
PY=$(command -v python3)
if [ -z "$PY" ]; then
  echo "Не найден Python 3. Установите его с https://www.python.org/downloads/ (или: xcode-select --install) и запустите снова."
  read -p "Нажмите Enter…"; exit 1
fi
"$PY" yaarchive.pyz "$@"
